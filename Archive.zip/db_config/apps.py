from django.apps import AppConfig


class DbConfigConfig(AppConfig):
    name = 'db_config'
