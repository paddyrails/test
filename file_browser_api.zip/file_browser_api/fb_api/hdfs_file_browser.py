import pyarrow as pa
import pyarrow.parquet as pq
import json
from pathlib import Path


def list_files(fs, root_dir):
    """list all folders and files in 'root_dir' folder"""
    
    files=[]
    folders=[]
    data=[]
    current_dir = root_dir
    
    if( not fs.exists(current_dir)):
        return data
    
    for entry_in_current_dir in fs.ls(current_dir):
        if len(entry_in_current_dir.strip()) > 0:
            path = Path(entry_in_current_dir);
            if(not fs.isdir(entry_in_current_dir)):
                info=fs.info(f"{path}")
                files.append({'name':f'{path.name}',
                                  'last_modified': info['last_modified'],
                                  'last_accessed' : info['last_accessed'], 
                                  'size':info['size'],
                                  'schema': get_file_schema(fs, entry_in_current_dir)
                             })
            else:
                files.append(entry_in_current_dir+"/")
                list_files(fs, entry_in_current_dir)
    data.append({"name":current_dir, "children":files})
    return data


def get_file_schema(fs, file_path):
    """gets schema details of parquet files only"""
    result=[]
    if(file_path.endswith('parquet') and not fs.isdir(f"{file_path}")):
        with fs.open(file_path) as file:
            schema=pq.read_schema(file)
            names = schema.names
            for name in names:
                result.append({name:str(schema.field_by_name(name).type)})
    return json.dumps(result)


def connect(host, user):
    #configure_server(host,user)
    fs = pa.hdfs.connect(host=host, user=user)
    return fs


def test(folder):
    fs = connect('localhost','mapr')
    #fs = connect('localhost','mapr')
    data = list_files(fs=fs, root_dir=folder)
    return data


