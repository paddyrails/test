from django.db import models


class FileRegistry(models.Model):
    file_registry_id = models.AutoField(primary_key=True, db_column="FILE_REGISTRY_ID")
#    model_registry_id = models.IntegerField(db_column="MODEL_REGISTRY_ID")
    is_input_file = models.CharField(max_length=1, db_column="IS_INPUT_FILE",choices=(('T','True'),('F','False')),default='T')
    is_active = models.CharField(max_length=1, db_column="IS_ACTIVE",choices=(('T','True'),('F','False')),default='T')
    file_name = models.CharField(max_length=500, db_column="FILE_NAME")
    folder_name = models.CharField(max_length=500,db_column="FOLDER_NAME")
    folder_alias = models.CharField(max_length=100, db_column="FOLDER_ALIAS")
    created_on = models.DateTimeField(auto_now_add=True, db_column = "CREATED_ON")

class FileSchema(models.Model):
    file_schema_id = models.AutoField(primary_key=True, db_column="FILE_SCHEMA_ID")
    file_registry_id = models.ForeignKey(to=FileRegistry,db_constraint=True, db_column="FILE_REGISTRY_ID", on_delete = None)
    field_name = models.CharField(max_length=500, db_column="FIELD_NAME")
    data_type = models.CharField(max_length=100, db_column="DATA_TYPE")
    is_active = models.CharField(max_length=1, db_column="IS_ACTIVE",choices=(('T','True'),('F','False')),default='T')
    created_on = models.DateTimeField(auto_now_add=True, db_column = "CREATED_ON")

class FolderStructureMaster(models.Model):
    fsm_id = models.AutoField(primary_key=True, auto_created=True, db_column="fsm_id")
    original_folder_name = models.CharField(max_length=500, db_column="original_folder_name")
    new_folder_name = models.CharField(max_length=500, db_column="new_folder_name")
    is_active = models.BooleanField(default=True, db_column="is_active")

    def __init__(self, original_folder_name, new_folder_name):
        self.original_folder_name=original_folder_name
        self.new_folder_name=new_folder_name
        self.is_active=True