from django.urls import path

from . import views

urlpatterns = [
    path('default', views.index, name='index'),
    path('browse', views.browse, name='browse'),
    path('connect', views.connect, name='connect'),
]