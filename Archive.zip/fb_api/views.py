from django.http import HttpResponse, JsonResponse
from . import hdfs_file_browser

host="192.168.190.133"
user="mapr"

fs = None

def index(request):
    return HttpResponse("Hello, world. You're at the polls index.")

def browse(request):
    """ file browser service """

    host = request.GET.get('host')
    host = 'localhost' if host == None else host
    print(f'connecting to {host}')

    base_folder = request.GET.get("folder")
    recursive = request.GET.get("recursive")
    if(base_folder == None):
        return HttpResponse("folder is a mandatory field, please pass it as HTTP GET or URL parameter")
    
    if(recursive == None):
        recursive = False

    output_object=None

    fs = hdfs_file_browser.connect(host,user)
    output_object = hdfs_file_browser.list_files(fs, base_folder)

    return JsonResponse(output_object, safe=False)

def connect(request):
    """ Connect or reconnect to MapR """
    global fs 
    request
    fs = hdfs_file_browser.connect(host,user)
    return HttpResponse("SUCCESS")